(() => {
var exports = {};
exports.id = 344;
exports.ids = [344];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 31707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'predictor',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43525)), "C:\\Repos\\personal-projects\\ge2024\\app\\predictor\\page.js"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51921)), "C:\\Repos\\personal-projects\\ge2024\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\Repos\\personal-projects\\ge2024\\app\\predictor\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/predictor/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/predictor/page",
        pathname: "/predictor",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 86772:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71374))

/***/ }),

/***/ 71374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(52451);
// EXTERNAL MODULE: ./app/data/ge2024-v6.json
var ge2024_v6 = __webpack_require__(3680);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./app/components/SideBarHeader.js
var SideBarHeader = __webpack_require__(45682);
// EXTERNAL MODULE: ./app/components/SideBarMainContent.js + 2 modules
var SideBarMainContent = __webpack_require__(6139);
// EXTERNAL MODULE: ./app/components/SideBarFooter.js
var SideBarFooter = __webpack_require__(44144);
;// CONCATENATED MODULE: ./app/components/VoteResult.js
/* __next_internal_client_entry_do_not_use__ default auto */ 
const VoteResult = ({ verdict })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `data-table-result ${verdict.verdictColor}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: "RESULT"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                src: "../Star.svg",
                alt: "Star"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: verdict.verdict
            })
        ]
    });
};
/* harmony default export */ const components_VoteResult = (VoteResult);

// EXTERNAL MODULE: ./app/components/Menu.js
var Menu = __webpack_require__(18908);
// EXTERNAL MODULE: ./app/components/SideBarMenuFooter.js
var SideBarMenuFooter = __webpack_require__(54858);
;// CONCATENATED MODULE: ./app/predictor/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 












function sumVotes(partyData, lookup, convertInt) {
    return partyData.reduce((accumulator, currentValue)=>{
        if (convertInt) {
            currentValue = parseInt(currentValue);
        }
        if (lookup) {
            if (currentValue === lookup) {
                accumulator++;
            }
            return accumulator;
        } else if (currentValue) {
            return accumulator + currentValue;
        } else {
            return accumulator;
        }
    }, 0);
}
function Page() {
    const [pollSliderPercentage, setPollSliderPercentage] = (0,react_.useState)(4);
    const [antiTorySliderPercentage, setAntiTorySliderPercentage] = (0,react_.useState)(20);
    const [reformToggle, setReformToggle] = (0,react_.useState)(true);
    const [verdict, setVerdict] = (0,react_.useState)({
        verdict: "Labour Majority of 10",
        verdictColor: "red"
    });
    const [menuState, setMenuState] = (0,react_.useState)(false);
    const handleMenu = ()=>{
        setMenuState(!menuState);
    };
    const [conservativeData, setConservativeData] = (0,react_.useState)({
        2019: 372,
        nowCast: 184,
        reform: 0
    });
    const [labourData, setLabourData] = (0,react_.useState)({
        2019: 199,
        nowCast: 386,
        reform: 0
    });
    const [liberalData, setLiberalData] = (0,react_.useState)({
        2019: 9,
        nowCast: 30,
        reform: 0
    });
    const [greenData, setGreenData] = (0,react_.useState)({
        2019: 1,
        nowCast: 1,
        reform: 0
    });
    const [reformData, setReformData] = (0,react_.useState)({
        2019: 0,
        nowCast: 0,
        reform: 0
    });
    const [snpData, setSnpData] = (0,react_.useState)({
        2019: 48,
        nowCast: 26,
        reform: 0
    });
    const [pcData, setPcData] = (0,react_.useState)({
        2019: 2,
        nowCast: 3,
        reform: 0
    });
    const [otherData, setOtherData] = (0,react_.useState)({
        2019: 1,
        nowCast: 2,
        reform: 0
    });
    const handlePollSliderChange = (newValue)=>{
        setPollSliderPercentage(newValue);
    };
    const handleAntiTorySliderChange = (newValue)=>{
        setAntiTorySliderPercentage(newValue);
    };
    const handleReformToggle = (event)=>{
        setReformToggle(event.target.checked);
        calculateVotes(event.target.checked, pollSliderPercentage, antiTorySliderPercentage);
    };
    const handlePollsTighten = ()=>{
        calculateVotes(reformToggle, pollSliderPercentage, antiTorySliderPercentage);
    };
    const calculateVotes = (reformToggle, pollSliderPercentage, antiTorySliderPercentage)=>{
        let conservativeSum = 0, labourSum = 0, liberalSum = 0, reformSum = 0, greenSum = 0, snpSum = 0, pcSum = 0, otherSum = 0;
        for(let i = 0; i <= 631; i++){
            let AP2 = 0, AQ2 = 0;
            const E2 = ge2024_v6/* 2.Lab */[2].D[i] - pollSliderPercentage / 100;
            let F2 = ge2024_v6/* 5.Lib */[5].G[i];
            let G2 = ge2024_v6/* 6.BRX */[6].$[i];
            let H2 = ge2024_v6/* 7.GRN */[7].a[i];
            let I2 = ge2024_v6/* 8.SNP */[8].G[i];
            let J2 = ge2024_v6[9].PC[i];
            F2 = F2 !== "" ? parseFloat(F2) : 0;
            G2 = G2 !== "" ? parseFloat(G2) : 0;
            H2 = H2 !== "" ? parseFloat(H2) : 0;
            I2 = I2 !== "" ? parseFloat(I2) : 0;
            J2 = J2 !== "" ? parseFloat(J2) : 0;
            const range1 = Math.max(E2, F2);
            const range2 = Math.max(H2, I2, J2);
            const V2 = E2 + F2 + H2 + I2 + J2;
            const U2 = Math.max(range1, range2);
            let AH2 = parseFloat(ge2024_v6/* 1.Con */[1].M[i]) + pollSliderPercentage / 100;
            const W2 = V2 - U2;
            const X2 = W2 * antiTorySliderPercentage / 100;
            let Y2 = U2 + X2;
            Y2 = parseFloat(Y2);
            const AI2 = E2 === U2 ? Y2 : E2;
            const AK2 = G2 === U2 ? Y2 : G2;
            if (reformToggle) {
                AP2 = AK2 * 0.7;
                AQ2 = AK2 * 0.3;
            }
            const AR2 = AH2 + AP2;
            let AS2 = AI2 + AQ2;
            let AT2 = F2 === U2 ? Y2 : F2;
            let AU2 = 0;
            let AV2 = H2 === U2 ? Y2 : H2;
            let AW2 = I2 === U2 ? Y2 : I2;
            let AX2 = J2 === U2 ? Y2 : J2;
            //let AY2 = 0;
            let AY2 = ge2024_v6/* 10.other */[10].Y[i];
            AY2 = parseFloat(AY2);
            const range3 = Math.max(AR2, AS2, AT2, AU2, AV2, AW2, AX2, AY2);
            let AZ2 = AR2 === range3 ? 1 : 0;
            let BA2 = AS2 === range3 ? 1 : 0;
            let BB2 = AT2 === range3 ? 1 : 0;
            let BC2 = AU2 === range3 ? 1 : 0;
            let BD2 = AV2 === range3 ? 1 : 0;
            let BE2 = AW2 === range3 ? 1 : 0;
            let BF2 = AX2 === range3 ? 1 : 0;
            let BG2 = AY2 === range3 ? 1 : 0;
            conservativeSum += AZ2;
            labourSum += BA2;
            liberalSum += BB2;
            reformSum += BC2;
            greenSum += BD2;
            snpSum += BE2;
            pcSum += BF2;
            otherSum += BG2;
        }
        //weird bug
        //if(pollSliderPercentage > 7 && pollSliderPercentage < 64) {conservativeSum -= 1;}
        setConservativeData((values)=>({
                ...values,
                reform: conservativeSum
            }));
        setLabourData((values)=>({
                ...values,
                reform: labourSum
            }));
        setLiberalData((values)=>({
                ...values,
                reform: liberalSum
            }));
        setReformData((values)=>({
                ...values,
                reform: reformSum
            }));
        setGreenData((values)=>({
                ...values,
                reform: greenSum
            }));
        setSnpData((values)=>({
                ...values,
                reform: snpSum
            }));
        setPcData((values)=>({
                ...values,
                reform: pcSum
            }));
        setOtherData((values)=>({
                ...values,
                reform: otherSum
            }));
        let verdict = "", verdictColor = "blue";
        const verdictRange = Math.max(conservativeSum, labourSum, liberalSum, reformSum, greenSum, snpSum, pcSum, otherSum);
        if (labourSum > 325) {
            verdict = `Labour majority of ${(labourSum - 325) * 2}`;
            verdictColor = "red";
        } else if (conservativeSum > 325) {
            verdict = `Conservative majority of ${(conservativeSum - 325) * 2}`;
        } else {
            verdict = `Hung Parliament ${325 - verdictRange} seats needed for a majority`;
            verdictColor = "navy";
        }
        setVerdict({
            verdict: verdict,
            verdictColor: verdictColor
        });
        console.log(verdict);
    };
    (0,react_.useEffect)(()=>{
        setConservativeData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 51.Con */[51].M, "", true)
            }));
        setLabourData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 52.Lab */[52].D, "", true)
            }));
        setLiberalData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 53.Lib */[53].G, "", true)
            }));
        setReformData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 54.BRX */[54].$, "", true)
            }));
        setGreenData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 55.GRN */[55].a, "", true)
            }));
        setSnpData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 56.SNP */[56].G, "", true)
            }));
        setPcData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6[57].PC, "", true)
            }));
        setOtherData((values)=>({
                ...values,
                reform: sumVotes(ge2024_v6/* 58.other */[58].Y, "", true)
            }));
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "predictor-section content-with-sidebar",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `sidebar ${menuState ? "menu-active" : ""}`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(SideBarHeader/* default */.Z, {
                            handleMenu: handleMenu
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "sidebar-main-container",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(SideBarMainContent/* default */.Z, {
                                    handlePollsTighten: handlePollsTighten,
                                    handlePollSliderChange: handlePollSliderChange,
                                    handleAntiTorySliderChange: handleAntiTorySliderChange,
                                    handleReformToggle: handleReformToggle,
                                    reformToggle: reformToggle
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "sidebar-footer",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "../Footer_Logo.svg",
                                            alt: "Logo"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            className: "colour-strip",
                                            src: "../Footer_Colour_Strip.svg",
                                            alt: "Colour Strip"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "open-menu-container",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu/* default */.Z, {})
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "main-content",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "intro-section",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "icon",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "../Vote_Icon.svg",
                                        alt: "Icon"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "THE ELECTION FORECAST"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "This tool lets you test the possible outcomes at the general election based on three strategic questions: First, how much will polls change between now and polling day? Second, how much tactical voting will take place on polling day? Third, will Reform UK candidates pose a meaningful challenge to Conservative PPCs across the country? By answering these three questions, informed by precedent and the effect that these events have had in the past, you can forecast who the next Prime Minister will be, what type of government they will lead, and what kind of Parliament they will work with."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "anchor-link",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#predictor-anchor",
                                        children: "VIEW THE PREDICTOR"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "data-table-section",
                            id: "predictor-anchor",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-headings",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-heading-col",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                                children: [
                                                    "NUMBER OF SEATS",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                    "IN GREAT BRITAIN"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-heading-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "2019 Result"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-heading-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Snapshot"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-heading-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Your prediction / Your result"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row blue",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Conservative"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: conservativeData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: conservativeData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: conservativeData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row red",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Labour"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: labourData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: labourData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: labourData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row orange",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Liberal Democrats"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: liberalData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: liberalData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: liberalData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row cyan",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Reform UK"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: reformData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: reformData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: reformData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row lightgreen",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Green"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: greenData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: greenData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: greenData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row yellow",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "SNP"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: snpData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: snpData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: snpData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row darkgreen",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Plaid Cymru"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: pcData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: pcData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: pcData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "data-table-row grey",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Other"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: otherData["2019"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: otherData["nowCast"]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "data-table-col",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: otherData["reform"]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(components_VoteResult, {
                                    verdict: verdict
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 43525:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Repos\personal-projects\ge2024\app\predictor\page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,530,848,628,975,680], () => (__webpack_exec__(31707)));
module.exports = __webpack_exports__;

})();