exports.id = 975;
exports.ids = [975];
exports.modules = {

/***/ 9951:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 52987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 50831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 44282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 16505, 23))

/***/ }),

/***/ 44144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ default auto */ 
const SideBarFooter = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "sidebar-footer",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "links",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.5654.co.uk",
                        target: "_blank",
                        className: "link",
                        children: "Visit Our Website"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.5654.co.uk/contact-us",
                        target: "_blank",
                        className: "link",
                        children: "Contact Us"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: "../Footer_Logo.svg",
                alt: "Logo"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: "colour-strip",
                src: "../Footer_Colour_Strip.svg",
                alt: "Colour Strip"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideBarFooter);


/***/ }),

/***/ 45682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ default auto */ 
const SideBarHeader = ({ handleMenu })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "sidebar-header",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                className: "menu-burger",
                onClick: handleMenu,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "menu-img activate-menu",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "../Menu_Button_2.svg",
                                alt: "Menu Burger",
                                className: "menu-burger state1"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "../Menu_Button_2.svg",
                                alt: "Menu Burger",
                                className: "menu-burger state2"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "menu-img deactivate-menu",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "../Menu_Close_Button_State_1.svg",
                                alt: "Menu Close",
                                className: "menu-close state1"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "../Menu_Close_Button_State_2.svg",
                                alt: "Menu Close",
                                className: "menu-close state2"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "header-title",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    children: "5654 ELECTION CENTRE"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideBarHeader);


/***/ }),

/***/ 6139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_SideBarMainContent)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Slider/index.js
var Slider = __webpack_require__(48839);
var Slider_default = /*#__PURE__*/__webpack_require__.n(Slider);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./app/components/GESlider.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


const GESlider = ({ title, helperText, handlePollsTighten, onChangeHandler, defaultValue, maxValue })=>{
    const [sliderValue, setSliderValue] = (0,react_.useState)(defaultValue);
    const handleSliderChange = (event)=>{
        setSliderValue(event.target.value);
        onChangeHandler(event.target.value);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "slider-container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "slider-title",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#!",
                        className: "help-icon",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "help-text",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: helperText
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "slide-container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Slider_default()), {
                        defaultValue: defaultValue,
                        "aria-label": title,
                        valueLabelDisplay: "auto",
                        onChange: handleSliderChange,
                        onMouseUp: ()=>handlePollsTighten(),
                        min: 0,
                        max: maxValue,
                        sx: {
                            width: 300,
                            width: "100%",
                            margin: "0",
                            height: "0.5vw",
                            borderRadius: "0.25vw",
                            color: "#f01e5b",
                            "& .MuiSlider-thumb": {
                                appearance: "none",
                                width: "1.5vw",
                                height: "1.5vw",
                                borderRadius: "50%",
                                background: "#fff",
                                border: "0.3vw solid red",
                                cursor: "pointer"
                            },
                            "& .MuiSlider-rail": {
                                color: "#fff",
                                opacity: "1"
                            }
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "slider-value",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "value",
                            children: [
                                sliderValue,
                                "%"
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_GESlider = (GESlider);

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Switch/index.js
var Switch = __webpack_require__(56703);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(16854);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(33987);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./app/components/GESwitch.js
/* __next_internal_client_entry_do_not_use__ default auto */ 



const GESwitch = ({ title, helperText, reformToggle, handleReformToggle })=>{
    const handleSwitch = ()=>{
        handleReformToggle();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "slider-container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "slider-title",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#!",
                        className: "help-icon",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "help-text",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: helperText
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "selector",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack/* default */.ZP, {
                    direction: "row",
                    spacing: 1,
                    alignItems: "center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            style: {
                                display: "flex",
                                width: "3.5vw",
                                height: "3.5vw",
                                borderRadius: "50%",
                                justifyContent: "center",
                                webkitBoxAlign: "center",
                                msFlexAlign: "center",
                                alignItems: "center",
                                webkitTransition: "0.3s ease-in-out",
                                transition: "0.3s ease-in-out",
                                cursor: "pointer",
                                fontWeight: "700"
                            },
                            className: `switch-text ${!reformToggle ? "active" : ""}`,
                            children: "No"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                            onChange: handleReformToggle,
                            checked: reformToggle,
                            sx: {
                                display: "-webkit-box",
                                display: "-ms-flexbox",
                                display: "flex",
                                webkitBoxPack: "justify",
                                msFlexPack: "justify",
                                justifyContent: "space-between",
                                webkitBoxAlign: "center",
                                msflexalign: "center",
                                alignItems: "center",
                                paddingTop: "1.5vw",
                                marginLeft: "0",
                                width: "calc(100% - 7vw)",
                                fontSize: "0.8vw"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            style: {
                                display: "flex",
                                width: "3.5vw",
                                height: "3.5vw",
                                borderRadius: "50%",
                                justifyContent: "center",
                                webkitBoxAlign: "center",
                                msFlexAlign: "center",
                                alignItems: "center",
                                webkitTransition: "0.3s ease-in-out",
                                transition: "0.3s ease-in-out",
                                cursor: "pointer",
                                fontWeight: "700"
                            },
                            className: `switch-text ${reformToggle ? "active" : ""}`,
                            children: "Yes"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_GESwitch = (GESwitch);

;// CONCATENATED MODULE: ./app/components/SideBarMainContent.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


const SideBarMainContent = ({ handlePollsTighten, handlePollSliderChange, handleAntiTorySliderChange, reformToggle, handleReformToggle })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar-main-content",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "THE NUMBER OF SEATS IN GREAT BRITAIN"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Use the choices below to make your prediction."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sliders",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_GESlider, {
                        title: "How much the polls will tighten?",
                        helperText: "Historically, the polls have tightened in the run-up to general elections, as undecided voters make up their minds. This happened to the Conservatives in 1997 (after 18 years in power) and Labour in 2010 (after 13 years in power). In both cases, the Government closed the Opposition’s lead by 8 to 10 percentage points in the final year.",
                        handlePollsTighten: handlePollsTighten,
                        onChangeHandler: handlePollSliderChange,
                        defaultValue: 4,
                        maxValue: 20
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_GESlider, {
                        title: "How much tactical voting will take place?",
                        helperText: "Ahead of the 2019 General Election, YouGov found 19% of people planned to vote tactically. While polling published after election found 32% of people said they voted tactically in 2019. Earlier this year, in the Selby and Ainsty and Uxbridge by-elections, the Liberal Democrats saw their vote share fall by 5.3 percentage points and 4.6 percentage points respectively. While in the Somerton and Frome by-election, Labour’s vote share fell 10.3 percentage points.",
                        handlePollsTighten: handlePollsTighten,
                        onChangeHandler: handleAntiTorySliderChange,
                        defaultValue: 20
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_GESwitch, {
                        title: "WILL REFORM UK FAIL TO BREAK THROUGH?",
                        helperText: "Analysis from the 2017 and 2019 General elections found that where the Brexit Party stood candidates, the change in vote share was more strongly correlated with Labour’s vote share falling than other parties.  Previous analysis found, in  the absence of a Brexit Party candidate, 70% of those who switched from Labour to the Brexit Party would have instead backed the Conservatives, while just 30% would have stuck with Labour.",
                        reformToggle: reformToggle,
                        handleReformToggle: handleReformToggle
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_SideBarMainContent = (SideBarMainContent);


/***/ })

};
;